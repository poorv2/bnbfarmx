export const version = "hash/5.0.5";
//# sourceMappingURL=_version.js.map